# quadratic-sieve
Math404 Coding Project
Keith Cressman, Colin Zhu, Aakash Kothapally

In this folder, we have the Python program (sieve.py), the paper (Quadratic_Sieve_Paper.pdf),
a text version of the python file (sieve.txt), and a pdf (Program_Output.pdf) that just contains 
a screenshot of the results of factoring the four numbers in the assignment writeup. 